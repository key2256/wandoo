// 선택탭 이미지 생성
const container = document.getElementById("선택그룹컨테이너");
const 이미지개수 = 2;

for (let i = 0; i < 이미지개수; i++) {
  const wrap = document.createElement("div");
  wrap.className = "선택목록";

  const img = document.createElement("img");
  img.src = "감정기록 off탭.png";
  img.className = "선택그룹";

  wrap.appendChild(img);
  container.appendChild(wrap);
}
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
});
document.querySelectorAll('.감정칩').forEach(el => observer.observe(el));



document.querySelectorAll('.감정칩').forEach(el => observer.observe(el));

function toggleSpeech(element) {
  element.classList.toggle("active");
}

const pages = document.querySelectorAll('.page');
const navButtons = document.querySelectorAll('.page-nav button');

const pageObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const index = [...pages].indexOf(entry.target);
      navButtons.forEach((btn, i) => {
        btn.classList.toggle('active', i === index);
      });
    }
  });
}, { threshold: 0.6 }); // 60% 이상 보일 때 해당 페이지로 판단

pages.forEach(page => pageObserver.observe(page));

const bgLayer = document.getElementById('background');

const pageColors = ['#FFFACD', '#FF8080', '#E0E0E0']; // 각 페이지별 색상

const bgObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const index = [...pages].indexOf(entry.target);
      bgLayer.style.backgroundColor = pageColors[index];
      bgLayer.classList.remove('bounce');
      void bgLayer.offsetWidth;
      bgLayer.classList.add('bounce');
    }
  });
}, { threshold: 0.6 });



pages.forEach(page => bgObserver.observe(page));


document.addEventListener("DOMContentLoaded", () => {
  const yellowTab = document.querySelector('.노랑탭');
  const blueTab = document.querySelector('.파랑탭');
  const redTab = document.querySelector('.빨강탭');

  function activateTab(targetTab) {
    [yellowTab, blueTab, redTab].forEach(tab => {
      if (tab === targetTab) {
        tab.classList.add('open');
        triggerBounce(tab);
      } else {
        tab.classList.remove('open');
      }
    });
  }

  function triggerBounce(tab) {
    tab.classList.remove('애니');
    void tab.offsetWidth; // 리플로우 트릭으로 재실행
    tab.classList.add('애니');
  }

  blueTab.addEventListener('click', () => activateTab(blueTab));
  yellowTab.addEventListener('click', () => activateTab(yellowTab));
  redTab.addEventListener('click', () => activateTab(redTab));
});


function playBounceAnimation(tab) {
  tab.classList.remove('애니'); // 다시 재생 위해 제거
  void tab.offsetWidth;         // 리플로우 강제
  tab.classList.add('애니');
}

//setTimeout(() => {
  //tab.classList.remove ('open');
//}, 20); // 20ms 정도 지연해서 jelly bounce 먼저 시작되게




  document.addEventListener("DOMContentLoaded", function () {
    const panel = document.getElementById("macaronPanel");
    const toggleBtn = document.getElementById("toggleBtn");

    let isOpen = false;

    toggleBtn.addEventListener("click", function () {
      isOpen = !isOpen;
      panel.classList.toggle("open", isOpen);
      toggleBtn.textContent = isOpen ? "◀" : "▶";
    });
  });

  
  document.addEventListener("DOMContentLoaded", function () {
    const panel = document.getElementById("polder");
    const toggleBtn = document.getElementById("toggleBtn2");

    let isOpen = false;

    toggleBtn.addEventListener("click", function () {
      isOpen = !isOpen;
      panel.classList.toggle("open", isOpen);
      toggleBtn.textContent = isOpen ? "◀" : "▶";
    });
  });


 window.addEventListener('DOMContentLoaded', () => {
  const 응가 = document.querySelector('.응가');
  const 응까 = document.querySelector('.응까');
  const 응까Wrapper = document.getElementById('응까-wrapper');
  const 응가Wrapper = 응가.parentElement;

  // 1. 응가 타이핑 끝날 때까지 기다림
  setTimeout(() => {
    // 응가 페이드아웃
    응가.classList.add('none');

    setTimeout(() => {
      // 응가 숨김 + 응까 보여줌
      응가Wrapper.classList.add('hidden');
      응까Wrapper.classList.remove('hidden');
      응까.classList.add('typing');
    }, 1000); // 응가 fade-out 끝난 후
  }, 3000); // 응가 타이핑 끝난 시점

  // 8.5초 후 intro 전체 제거 + 페이지 이동
  setTimeout(() => {
    const intro = document.getElementById('intro');
    const page1 = document.getElementById('page1');
    intro.style.transition = 'opacity 1.5s ease';
    intro.style.opacity = '0';

    setTimeout(() => {
      intro.style.display = 'none';
      page1.scrollIntoView({ behavior: 'smooth' });
    }, 1500);
  }, 8500);
});
